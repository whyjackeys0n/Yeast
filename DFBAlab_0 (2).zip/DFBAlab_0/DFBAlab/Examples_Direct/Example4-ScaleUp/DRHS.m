%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DFBAlab: Dynamic Flux Balance Analysis laboratory                       %
% Process Systems Engineering Laboratory, Cambridge, MA, USA              %
% July 2014                                                               %
% Written by Jose A. Gomez and Kai H�ffner                                %
%                                                                         % 
% This code can only be used for academic purposes. When using this code  %
% please cite:                                                            %
%                                                                         %
% Gomez, J.A., H�ffner, K. and Barton, P. I.                              %
% DFBAlab: A fast and reliable MATLAB code for Dynamic Flux Balance       %
% Analysis. Submitted.                                                    %
%                                                                         %
% COPYRIGHT (C) 2014 MASSACHUSETTS INSTITUTE OF TECHNOLOGY                %
%                                                                         %
% Read the LICENSE.txt file for more details.                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function dy = DRHS(t, y, INFO)
% Initial conditions
% Y1 = Volume (L)
% Y2 = Biomass (gDW/L)
% Y3 = CO2
% Y4 = Acetate
% Y5 = O2
% Y6 = Penalty

% Assign values from states
nmodel = INFO.nmodel;
for i=1:3
   S(i) = y(1+nmodel+i);
end

% Feed rates
Fin = 1.001;
Fout = 1.001;

% Mass transfer coefficients
KhO2 = 0.0013;
KhCO2 = 0.035;

% Mass transfer expressions
MT(1) = 0.58*(KhCO2*0.00035*1000 - S(1));
MT(2) = 0;
MT(3) = 0.6*(KhO2*0.21*1000 - S(3)); 

% Substrate feed concentrations
Sfeed(1) = KhCO2*0.00035*1000;
Sfeed(2) = 32.9;
Sfeed(3) = KhO2*0.21*1000;

% The elements of the flux matrix have the sign given to them by the
% coefficients in the Cost vector in main. 
% Example, if:
% C{k}(i).rxns = [144, 832, 931];
% C{k}(i).wts = [3, 1, -1];
% Then the cost vector for this LP will be:
% flux(k,i) = 3*v_144 + v_832 - v_931 
% The penalty is an array containing the feasibility LP problem optimal
% objective function value for each model. 

%% Update bounds and solve for fluxes
INFO.t = t;
[lbx,ubx]=RHS(t,y,INFO);
[ flux,penalty ] = ModelObjsSolve( INFO, lbx, ubx);
%%

%% Dynamics
dy = zeros(nmodel+5,1);    % a column vector
dy(1) = Fin-Fout;    % Volume
for i=1:nmodel
    dy(i+1) = flux(i,1)*y(i+1) - y(i+1)*Fout/y(1);   % Biomass
end
for i=1:nmodel
    dy(nmodel+1+1) = dy(nmodel+1+1) + flux(i,4)*y(i+1);
    dy(nmodel+1+2) = dy(nmodel+1+2) + flux(i,2)*y(i+1);
    dy(nmodel+1+3) = dy(nmodel+1+3) + flux(i,3)*y(i+1);
    dy(nmodel+1+4) = dy(nmodel+1+4) + penalty(i);
end

dy(nmodel+1+1) = dy(nmodel+1+1) + (Sfeed(1)*Fin-y(nmodel+1+1)*Fout)/y(1) + MT(1);   % CO2
dy(nmodel+1+2) = dy(nmodel+1+2) + (Sfeed(2)*Fin-y(nmodel+1+2)*Fout)/y(1) + MT(2);    % Acetate
dy(nmodel+1+3) = dy(nmodel+1+3) + (Sfeed(3)*Fin-y(nmodel+1+3)*Fout)/y(1) + MT(3);    % oxygen

end