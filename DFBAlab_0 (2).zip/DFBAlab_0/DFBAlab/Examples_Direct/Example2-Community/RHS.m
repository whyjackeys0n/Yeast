%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DFBAlab: Dynamic Flux Balance Analysis laboratory                       %
% Process Systems Engineering Laboratory, Cambridge, MA, USA              %
% July 2014                                                               %
% Written by Jose A. Gomez and Kai H�ffner                                %
%                                                                         % 
% This code can only be used for academic purposes. When using this code  %
% please cite:                                                            %
%                                                                         %
% Gomez, J.A., H�ffner, K. and Barton, P. I.                              %
% DFBAlab: A fast and reliable MATLAB code for Dynamic Flux Balance       %
% Analysis. Submitted.                                                    %
%                                                                         %
% COPYRIGHT (C) 2014 MASSACHUSETTS INSTITUTE OF TECHNOLOGY                %
%                                                                         %
% Read the LICENSE.txt file for more details.                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [lb,ub] = RHS( t,y,INFO )

% This subroutine updates the upper and lower bounds for the fluxes in the
% exID arrays in main. The output should be two matrices, lb and ub. The lb matrix
% contains the lower bounds for exID{i} in the ith row in the same order as
% exID. The same is true for the upper bounds in the ub matrix.
% Infinity can be used for unconstrained variables, however, it should be 
% fixed for all time. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Yeast 
% Glucose
if (y(4)<0)
    lb(1,1) = 0;
else
    lb(1,1) = -(20*y(4)/(0.5/0.18 + y(4)))*1/(1+y(7)/(10/0.046));
end
ub(1,1) = 0;

% Oxygen
lb(1,2) = -8*y(5)/(0.003/0.016 + y(5));
ub(1,2) = 0;

% CO2
lb(1,3) = 0;
ub(1,3) = Inf;

% Ethanol
lb(1,4) = 0;
ub(1,4) = Inf;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Algae
% HCO3
lb(2,1) = 0;
ub(2,1) = 0;

% Acetate
lb(2,2) = -14.9*y(8)/(2.2956+y(8)+y(8)^2/0.1557);
ub(2,2) = 0;

% Oxygen 
lb(2,3) = -1.41750070911*y(5)/(0.009+y(5));
ub(2,3) = Inf;

% CO2
% if y(6) < 0
%     lb(2,4) = 0;
% else
    lb(2,4) = -2.64279793224*y(6)/(0.0009+y(6));
% end
ub(2,4) = Inf;

% Light
Ke1 = 0.32;
Ke2 = 0.03;
L = 0.4; % meters depth of pond
Ke = Ke1 + Ke2*(y(3)+y(2)/2);
Io = 28*(max(sin(2*pi()*t/48)^2,sin(2*pi()*5/48)^2)-sin(2*pi()*5/48)^2)/(1-sin(2*pi()*5/48)^2);
lb(2,5) = 0;
ub(2,5) = Io*(1-exp(-L*Ke))/(Ke*L);

for i=6:16
   lb(2,i) = 0;
   ub(2,i) = 0;
end

% H+
lb(2,17) = -10;
ub(2,17) = Inf;

% Autotrophic growth
lb(2,18) = 0;
ub(2,18) = 0;

% Mixotrophic growth
lb(2,19) = 0;
ub(2,19) = Inf;

% Heterotrophic growth
lb(2,20) = 0;
ub(2,20) = 0;

% Non-growth associated ATP maintenance
lb(2,21) = 0.183;
ub(2,21) = 0.183;

% Starch
lb(2,22) = 0;
ub(2,22) = 0;

% Photoevolved oxygen
lb(2,23) = 0;
ub(2,23) = 8.28;

% Ethanol
lb(2,24) = 0;
ub(2,24) = 0;

end

