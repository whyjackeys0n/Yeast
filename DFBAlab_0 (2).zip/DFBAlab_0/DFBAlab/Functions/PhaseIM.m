%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DFBAlab: Dynamic Flux Balance Analysis laboratory                       %
% Process Systems Engineering Laboratory, Cambridge, MA, USA              %
% July 2014                                                               %
% Written by Jose A. Gomez                                                %
% Revised by Kai H�ffner                                                  %
%                                                                         % 
% This code can only be used for academic purposes. When using this code  %
% please cite:                                                            %
%                                                                         %
% Gomez, J.A., H�ffner, K. and Barton, P. I.                              %
% DFBAlab: A fast and reliable MATLAB code for Dynamic Flux Balance       %
% Analysis. Submitted.                                                    %
%                                                                         %
% COPYRIGHT (C) 2014 MASSACHUSETTS INSTITUTE OF TECHNOLOGY                %
%                                                                         %
% Read the LICENSE.txt file for more details.                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [model,C,pair] = PhaseIM(model,nmodel,exID,ncost)

for k=1:nmodel
    for i = 1:length(exID{k})
        model{k}.lb(exID{k}(i)) = -Inf;
        model{k}.ub(exID{k}(i)) = Inf;
    end

    [model{k},pair{k}]=LPstandardform(model{k},exID{k});
    % Phase I LP construction

    A = model{k}.A;
    b = model{k}.b;
    cost = model{k}.c;

    [m,n] = size(A);
    
    for i = 1:length(exID{k})
        A(i,n+i) = 1;
        A(m+1,n+i) = 1;
        A(length(exID{k})+i,n+length(exID{k})+i) = -1;
        A(m+1,n+length(exID{k})+i) = 1;
        cost(n+i) = 0;
        cost(n+length(exID{k})+i) = 0;
    end
        ct = 2*length(exID{k})+1;
    for i = 2*length(exID{k})+1:m
        if b(i)<0
           A(i,n+ct) = -1;
           A(m+1,n+ct) = 1;
           cost(n+ct) = 0;
           ct = ct + 1;
        else
            A(i,n+ct) = 1;
            A(m+1,n+ct) = 1;
            cost(n+ct) = 0;
            ct = ct + 1;
        end
    end
    A(m+1,n+ct) = -1;
    cost(n+ct) = 0;
    b(m+1) = 0;        
   

    lb = zeros(size(A,2),1);
    ub = Inf*ones(size(A,2),1);
    C{k} = zeros(size(A,2),ncost(k));
    % Cost matrix for phase I LP
    C{k}(size(A,2),1) = 1;
    model{k}.A = A;
    model{k}.b = b;
    model{k}.c = cost;
    model{k}.lb = lb;
    model{k}.ub = ub;
end
return