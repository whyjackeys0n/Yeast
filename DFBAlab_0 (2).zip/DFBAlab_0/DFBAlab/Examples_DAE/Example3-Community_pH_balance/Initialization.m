function [ x ] = Initialization(  )

% x0 = [1 4 0.5 0.06 0.4994 1E-7];           % Make a starting guess at the solution
x0 = [4.9 1E-1 0 1 0 1E-7];
options=optimset('Display','iter');   % Option to display output
[x,fval,exitflag,output] = fsolve(@myfun,x0,options)

return

function F = myfun(x)
Ka = 10^-9.4003;
K1c = 10^-6.3819;
K2c = 10^-10.3767;
Nt = 2.3/14;
Ct = 1.05;

F = [-x(1) + Nt*x(6)/(x(6) + Ka) ;
      -x(4) + x(1)/(1 + 2*K2c/x(6));
      -x(3) + x(6)*x(4)/K1c;
      -x(5) + x(4)*K2c/x(6);
      -Nt + x(1) + x(2)
      -Ct + x(3) + x(4) + x(5)];
return