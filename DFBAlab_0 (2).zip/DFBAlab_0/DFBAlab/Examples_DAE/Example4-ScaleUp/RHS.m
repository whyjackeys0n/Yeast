%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DFBAlab: Dynamic Flux Balance Analysis laboratory                       %
% Process Systems Engineering Laboratory, Cambridge, MA, USA              %
% July 2014                                                               %
% Written by Jose A. Gomez and Kai H�ffner                                %
%                                                                         % 
% This code can only be used for academic purposes. When using this code  %
% please cite:                                                            %
%                                                                         %
% Gomez, J.A., H�ffner, K. and Barton, P. I.                              %
% DFBAlab: A fast and reliable MATLAB code for Dynamic Flux Balance       %
% Analysis. Submitted.                                                    %
%                                                                         %
% COPYRIGHT (C) 2014 MASSACHUSETTS INSTITUTE OF TECHNOLOGY                %
%                                                                         %
% Read the LICENSE.txt file for more details.                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [lb,ub] = RHS( t,y,INFO )
nmodel = INFO.nmodel;

% Initial conditions
% Y1 = Volume (L)
% Y2 = Biomass (gDW/L)
% Y3 = CO2
% Y4 = Acetate
% Y5 = O2
% Y6 = Penalty

% This subroutine updates the upper and lower bounds for the fluxes in the
% exID arrays in main. The output should be two matrices, lb and ub. The lb matrix
% contains the lower bounds for exID{i} in the ith row in the same order as
% exID. The same is true for the upper bounds in the ub matrix.
% Infinity can be used for unconstrained variables, however, it should be 
% fixed for all time. 

for j = 1:nmodel
    % Algae
    % HCO3
    lb(j,1) = 0;
    ub(j,1) = 0;

    % Acetate
    lb(j,2) = -2*y(1+nmodel+2)/(0.5+y(1+nmodel+2));
    ub(j,2) = Inf;

    % Oxygen 
    lb(j,3) = -1.41750070911*y(1+nmodel+3)/(0.009+y(1+nmodel+3));
    ub(j,3) = Inf;

    % CO2
    if y(1+nmodel+1) < 0
        lb(j,4) = 0;
    else
        lb(j,4) = -0.21512*0.022*y(1+nmodel+1)/(0.01844+y(1+nmodel+1));
    end
    ub(j,4) = Inf;

    % Light
    Ke1 = 0.32;
    Ke2 = 0.03;
    L = 0.4; % meters depth of pond
    biomass = 0;
    for i = 1:nmodel
       biomass = biomass + y(1+i); 
    end
    
    Ke = Ke1 + Ke2*(biomass);
    Io = 28*(max(sin(2*pi()*t/48)^2,sin(2*pi()*5/48)^2)-sin(2*pi()*5/48)^2)/(1-sin(2*pi()*5/48)^2);
    lb(j,5) = 0;
    ub(j,5) = Io*(1-exp(-L*Ke))/(Ke*L);

    for i=6:16
       lb(j,i) = 0;
       ub(j,i) = 0;
    end

    % H+
    lb(j,17) = -10;
    ub(j,17) = Inf;

    % Autotrophic growth
    lb(j,18) = 0;
    ub(j,18) = 0;

    % Mixotrophic growth
    lb(j,19) = 0;
    ub(j,19) = Inf;

    % Heterotrophic growth
    lb(j,20) = 0;
    ub(j,20) = 0;

    % Non-growth associated ATP maintenance
    lb(j,21) = 0.183;
    ub(j,21) = 0.183;

    % Starch
    lb(j,22) = 0;
    ub(j,22) = 0;

    % Photoevolved oxygen
    lb(j,23) = 0;
    ub(j,23) = 8.28;

    % Ethanol
    lb(j,24) = 0;
    ub(j,24) = 0;

end
end

