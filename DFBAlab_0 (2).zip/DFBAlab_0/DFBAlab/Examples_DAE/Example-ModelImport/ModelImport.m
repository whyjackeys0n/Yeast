%% Setup
clear all
addpath('C:\Users\Jos�\Dropbox\Joseal - MIT\Research\cobra')
initCobraToolbox
iND750=readCBModel('iND750',1000,'SBML')
clear c1 S1 b1 lb1 ub1 c S lb ub b x fval

c=-iND750.c;
S=iND750.S;
lb=iND750.lb;
ub=iND750.ub;
b=iND750.b;

save iND750.mat iND750